%% Introduction
% Identify the convection initiation (CI) events using the CI algorithm of
% "FCB2013_Modified" which is adapted from Fabry et al. (2013).
%
% Coded by Lanqiang BAI (bailanqiang@foxmail.com)
%
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%
% Main procedures:
% ===1st=== Binarize all the mosaic maps to be 25/35/40-dBZ BW images.
% ===2nd=== Find all the convective cells (>= 40 dBZ).
% ===3rd=== Find the first-occurrence convective cells.
% ===4th=== Apply "FCB2013_Modified" to the detected first-occurrence 
%           convective cells and output the location & time of the 
%           identified CI cells.
% 
% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

%% main program
clc;clear;close all;

% Binarize all the mosaic maps to be 25/35/40-dBZ BW images.
addpath('./sub_functions');
load('grid_lon_lat.mat');
grid_range=sub_grid_numbers_for_60km_100km_searching_circle;
sub_get_mosaic_map_to_BW_image(2017,6,1,20);

datapath_40dBZ = '../Middle_data/Middle_data_40dBZ/'; 
datapath_25dBZ = '../Middle_data/Middle_data_25dBZ/'; 
datapath_35dBZ = '../Middle_data/Middle_data_35dBZ/'; 

File=dir([datapath_40dBZ,'*.png']);
N_imgage = length(File);

%% Searching CI events
total_CI=0;total_40dBZ_cells=0;if_CI=0;CIinfo=[];
if N_imgage > 0
    for j =6:N_imgage
    fprintf(1,['Searching CI:  progress report = %02d/%d  ','\n'],j,N_imgage);    
    image_name = File(j).name;
    [bw_img,img_reg]=sub_locate_convection(datapath_40dBZ,image_name);
    
%====== Locate all the convection cells
    num_convection=length(img_reg(:,1));
    total_40dBZ_cells=total_40dBZ_cells+num_convection;
    
    if ~num_convection==0
        convection_centroid0=cat(1,img_reg.Centroid);
        rects0 = cat(1,img_reg.BoundingBox);  
        filename_out=sub_filename_every_6min(image_name); % Get the filenames prior to the checking time.
        [convection_centroid_buffer_domain_60km,rects]=sub_centroid_domain_buffer_60km(convection_centroid0,rects0,60);% use 60 km first, sub-function will update the buffer domain if necessary.
        [if_CI]=sub_check_CI_FCB2013_modified(datapath_40dBZ,datapath_35dBZ,datapath_25dBZ,filename_out,convection_centroid_buffer_domain_60km,grid_range);
        
%====== write the CI time and location  ============================================================ 
        num_CI=sum(if_CI);temp=find(if_CI(:,1)==1);
        loc_grid=convection_centroid_buffer_domain_60km(temp,:);        
        rects_CI=rects(temp,:);
        if num_CI>0
            for n=1:num_CI
                loc_ll=[grid_lon(loc_grid(1),loc_grid(2)),grid_lat(loc_grid(2),loc_grid(2))];
                CIinfo(total_CI+n).CI_time=image_name(12:24); % CI time in UTC
                CIinfo(total_CI+n).CI_loc=loc_ll(n,:);        % CI location in longitude/latitude
            end
            total_CI=total_CI+num_CI;
        end
        
    end
    end
end

%% Check the identified CI events
if ~isempty(total_CI)
    fprintf(1,'\nA total of %d CI events is identified, please check the struct variable "CIinfo".\n\n',total_CI);   
else
    disp('No CI event is identified!')
end

% Remove the middle data
rmdir('../Middle_data','s');
