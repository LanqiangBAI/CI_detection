function sub_get_mosaic_map_to_BW_image(year_input,month_input,image_start,image_end)
% example:
% sub_get_mosaic_map_to_BW_image(2017,6,1,50)
% 

%% data path & get file names of the mosaic maps
datatime=[num2str(year_input),num2str(month_input,'%02d')];
datapath      = '../DATA_mosaic_maps/';
outpath_40dBZ = '../Middle_data/Middle_data_40dBZ/'; mkdir(outpath_40dBZ);
outpath_25dBZ = '../Middle_data/Middle_data_25dBZ/'; mkdir(outpath_25dBZ);
outpath_35dBZ = '../Middle_data/Middle_data_35dBZ/'; mkdir(outpath_35dBZ);
    
allnames = struct2cell(dir([datapath,'*.PNG']));   
[m,n] = size(allnames); namelist=cell(1,n);
for i = 1:n                         
    name = allnames(1,i);
    namelist(i) = name;
end

%%
figure('visible','off')
for i1=image_start:image_end
filename=char(namelist(i1));
fprintf(1,['Binarizing images  %02d/%d  %s\n'],i1,n,filename);
echo=sub_get_echo_from_RGB(datapath,filename);
echo(371:589,720:765)=nan;% remove the colorbar pixels

%=============================================================== 40 dBZ
Echo40=echo;
Echo40(isnan(Echo40))=0;Echo40(Echo40<40)=0;Echo40(Echo40>=40)=100;
cmap=[0 0 0;1 1 1];colormap(cmap);
image(Echo40);shading flat;
name_40dBZ=[filename(1:24),'_40dBZ.png'];
imwrite(Echo40,[outpath_40dBZ,name_40dBZ]);

%=============================================================== 35 dBZ
Echo35=echo;
Echo35(isnan(Echo35))=0;Echo35(Echo35<35)=0;Echo35(Echo35>=35)=100;
cmap=[0 0 0;1 1 1];colormap(cmap);
image(Echo35);shading flat;
name_35dBZ=[filename(1:24),'_35dBZ.png'];
imwrite(Echo35,[outpath_35dBZ,name_35dBZ]);

%=============================================================== 25 dBZ
Echo25=echo;
Echo25(isnan(Echo25))=0;Echo25(Echo25<25)=0;Echo25(Echo25>=25)=100;
cmap=[0 0 0;1 1 1];colormap(cmap);
image(Echo25);shading flat;
name_25dBZ=[filename(1:24),'_25dBZ.png'];
imwrite(Echo25,[outpath_25dBZ,name_25dBZ]);

end

end
