function DATA = sub_cressman(lon,lat,data_lon,data_lat,data,R,init_b)   

% lon : the grid to be interpolated.
% lat : the grid to be interpolated.
% init_b : initial backgroud data (first guess) at the grid to be interpolated.
% R: influence radius (unit: number of image pixels)

[m,n]=size(data);
b=~isnan(data);
if sum(sum(b))==0
    DATA=nan;return;
end
data=reshape(data,m*n,1);
data_lon=reshape(data_lon,m*n,1);
data_lat=reshape(data_lat,m*n,1);
temp1=isnan(data);
data(temp1)=[];
data_lon(temp1)=[];
data_lat(temp1)=[];
    
% Exponential weighting function
anal=0;total_weight=0;
for kk=1:length(data)
    dx=abs(lon-data_lon(kk));
    dy=abs(lat-data_lat(kk));
    dis=sqrt(dx.^2+dy.^2);            
    if ~isnan(dis)
        weight = exp(-dis.^2./ (2*R.^2));
        anal = anal + (data(kk)-init_b)*weight;                    
        total_weight=total_weight+weight;
    end
end
if total_weight == 0
    anal=0;
else
    anal=anal./total_weight+init_b;
end

DATA=anal;
if DATA==0
    DATA=nan;
end
end