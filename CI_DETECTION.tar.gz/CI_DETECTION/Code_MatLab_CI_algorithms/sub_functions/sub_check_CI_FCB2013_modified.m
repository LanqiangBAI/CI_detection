function [if_CI]=sub_check_CI_FCB2013_modified(datapath_40dBZ,datapath_35dBZ,datapath_25dBZ,filename_out,convection_centroid_100km,grid_range) 

Nx_30km = grid_range.Nx_30km;
Ny_30km = grid_range.Ny_30km;
Nx_60km = grid_range.Nx_60km;
Ny_60km = grid_range.Ny_60km;
Nx_100km = grid_range.Nx_100km;
Ny_100km = grid_range.Ny_100km;

if_CI=ones(length(convection_centroid_100km(:,1)),1);

% =========================================================================================================================
% No pixel >=40 dBZ within 30 min prior to the checking point within 30 km.
    for time_6min=1:5
        temp_k=0;
        image_name=char(filename_out(time_6min,1));
        if exist([datapath_40dBZ,image_name],'file')==2
            img =  imread([datapath_40dBZ,image_name]);
            gray_img=img;  % Black-White image
            T = graythresh(gray_img);  
            bw_img = imbinarize(gray_img, T);  
            bw_img=bw_img';% image matrix with 800 x 600 pixels
            for i=1:length(if_CI)
                for j=1:length(Nx_30km)
                    temp=bw_img(Nx_30km(j)+convection_centroid_100km(i,1),Ny_30km(j)+convection_centroid_100km(i,2)); 
                    if temp~=0; if_CI(i)=nan;
                        break;
                    end 
                end
            end

        else 
            temp_k=temp_k+1;
            if temp_k==2
                if_CI(:)=nan; % if there are 2 modsic maps missing (within 12 min), then give up this image case.
                return; 
            end 
        end 
    end
       
% No pixel above 25 dBZ was observed 30 min prior to the convective cell within 60 km.
for i2=1:length(if_CI)
    if ~isnan(if_CI(i2))
        if_CI(i2)=sub_CI_check_criteria_I_25dBZ_30min_prior(filename_out,datapath_35dBZ,datapath_25dBZ,if_CI(i2),convection_centroid_100km(i2,:),Nx_60km,Ny_60km,Nx_100km,Ny_100km); 
    end
end

if_CI(isnan(if_CI))=0;

end


% No pixel above 25 dBZ was observed 30 min prior to the convective cell within 60 km.
function if_CI=sub_CI_check_criteria_I_25dBZ_30min_prior(filename_out,datapath_35dBZ,datapath_25dBZ,if_CI,convection_centroid_100km,Nx_60km,Ny_60km,Nx_100km,Ny_100km)

time_30min=6;
filename_30min_35dBZ=filename_out(7,1);
filename_60min_25dBZ=filename_out(8,1);
image_name=char(filename_out(time_30min,1));

if exist([datapath_25dBZ,image_name],'file')==2
    img =  imread([datapath_25dBZ,image_name]);
    gray_img=img;  % Black-White image
    T = graythresh(gray_img);  
    bw_img = imbinarize(gray_img, T);  
    bw_img=bw_img';% image matrix with 800 x 600 pixels
    
    for j=1:length(Nx_60km)
        temp=bw_img(Nx_60km(j)+convection_centroid_100km(1),Ny_60km(j)+convection_centroid_100km(2));
        if temp
            if_CI=0; 
            break; 
        end
    end
    
    % if criteria I is failed, then apply criteria II.
    if if_CI==0 
        if_CI=sub_CI_check_criteria_II(datapath_35dBZ,datapath_25dBZ,filename_30min_35dBZ,filename_60min_25dBZ,convection_centroid_100km,Nx_60km,Ny_60km,Nx_100km,Ny_100km);% alternative 35-dBZ criteria
    end

else
    if_CI=0; 
end

end

function if_CI_temp=sub_CI_check_criteria_II(datapath_35dBZ,datapath_25dBZ,image_name_35dBZ,image_name_25dBZ,convection_centroid_temp,Nx_60km,Ny_60km,Nx_100km,Ny_100km)
% =========================================================================================================================
% II) No pixels reaching 35 dBZ was observed 30 min prior the convection event within 60 km of the expected position of the cell, 
% and no pixels exceeding 25 dBZ was observed 60 min prior the convection event within 100 km of the expected position of the cell.
% Adapted from Fabry

% domain buffer first (100 km)
Nx_upper_limit=46;

convection_centroid0=round(convection_centroid_temp);
if convection_centroid0(1,1)-Nx_upper_limit<=0 | convection_centroid0(1,2)-Nx_upper_limit<=0
    convection_centroid0(1,1)=nan;
elseif convection_centroid0(1,1)+Nx_upper_limit>=800 | convection_centroid0(1,2)+Nx_upper_limit>=600
    convection_centroid0(1,1)=nan;
end

if ~isnan(convection_centroid0(1,1))
    image_name_35dBZ=char(image_name_35dBZ);
    image_name_25dBZ=char(image_name_25dBZ);
    
    if exist([datapath_35dBZ,image_name_35dBZ],'file')==2
        if_CI_temp=1;
        img =  imread([datapath_35dBZ,image_name_35dBZ]);
        gray_img=img;
        T = graythresh(gray_img);  
        bw_img = imbinarize(gray_img, T);  
        bw_img=bw_img';
        for j=1:length(Nx_60km)
            temp=bw_img(Nx_60km(j)+convection_centroid_temp(1),Ny_60km(j)+convection_centroid_temp(2)); 
            if temp
                if_CI_temp=0; 
                break; 
            end 
        end
        
        if if_CI_temp==1
           if_CI_temp=sub_CI_check_criteria_II_25dBZ_60min_prior(datapath_25dBZ,image_name_25dBZ,convection_centroid_temp,if_CI_temp,Nx_100km,Ny_100km);
        end
        
    else
        if_CI_temp=0;
    end
    
else
    if_CI_temp=0;
end

end


function if_CI_temp=sub_CI_check_criteria_II_25dBZ_60min_prior(datapath_25dBZ,image_name_25dBZ,convection_centroid_temp,if_CI_temp,Nx_100km,Ny_100km)  

if exist([datapath_25dBZ,image_name_25dBZ],'file')==2
    img =  imread([datapath_25dBZ,image_name_25dBZ]);
    gray_img=img;
    T = graythresh(gray_img);  
    bw_img = imbinarize(gray_img, T);  
    bw_img=bw_img';
    for j=1:length(Nx_100km)
        temp=bw_img(Nx_100km(j)+convection_centroid_temp(1),Ny_100km(j)+convection_centroid_temp(2)); 
        if temp
            if_CI_temp=0;
            break;
        end
    end
    
else
    if_CI_temp=0;
end

end
