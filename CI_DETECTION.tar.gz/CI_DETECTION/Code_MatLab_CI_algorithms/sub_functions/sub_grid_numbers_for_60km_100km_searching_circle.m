function grid_range = sub_grid_numbers_for_60km_100km_searching_circle

x0=0;y0=0;
Nx_30km=[];Ny_30km=[];Nx_60km=[];Ny_60km=[];Nx_100km=[];Ny_100km=[];


for j=-150:150
    for i=-100:100
        dx=(i-x0)*2.15; dy=(j-y0)*2.15;
        dis=sqrt(dx.^2+dy.^2);
        if dis<=30
            Nx_30km=[Nx_30km,i];Ny_30km=[Ny_30km,j];
        end
    end
end

for j=-150:150
    for i=-100:100
        dx=(i-x0)*2.15; dy=(j-y0)*2.15;
        dis=sqrt(dx.^2+dy.^2);
        if dis<=60
            Nx_60km=[Nx_60km,i];Ny_60km=[Ny_60km,j];
        end
    end
end

for j=-150:150
    for i=-100:100
        dx=(i-x0)*2.15; dy=(j-y0)*2.15;
        dis=sqrt(dx.^2+dy.^2);
        if dis<=100
            Nx_100km=[Nx_100km,i];Ny_100km=[Ny_100km,j];
        end
    end
end

grid_range.Nx_30km=Nx_30km;
grid_range.Ny_30km=Ny_30km;
grid_range.Nx_60km=Nx_60km;
grid_range.Ny_60km=Ny_60km;
grid_range.Nx_100km=Nx_100km;
grid_range.Ny_100km=Ny_100km;

end