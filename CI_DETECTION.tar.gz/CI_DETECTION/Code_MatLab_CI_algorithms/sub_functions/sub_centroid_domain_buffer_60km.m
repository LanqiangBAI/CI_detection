function [convection_centroid,rects]=sub_centroid_domain_buffer_60km(convection_centroid0,rects0,buffer_dis)    
%% give a 100km or 60km buffer domain.
% buffer_dis: in km

if buffer_dis==60
    Nx_upper_limit=27;% 60 km
elseif buffer_dis==100
    Nx_upper_limit=46;% 100 km 
end


convection_centroid0=round(convection_centroid0);
for i=1:length(convection_centroid0(:,1))
    if convection_centroid0(i,1)-Nx_upper_limit<=0 | convection_centroid0(i,2)-Nx_upper_limit<=0
        convection_centroid0(i,1)=nan;rects0(i,1)=nan;
    elseif convection_centroid0(i,1)+Nx_upper_limit>=800 | convection_centroid0(i,2)+Nx_upper_limit>=600
        convection_centroid0(i,1)=nan;;rects0(i,1)=nan;
    end
    
end
temp= isnan(convection_centroid0(:,1));
convection_centroid0(temp,:)=[];
convection_centroid=convection_centroid0;

temp= isnan(rects0(:,1));
rects0(temp,:)=[];
rects=rects0;
end