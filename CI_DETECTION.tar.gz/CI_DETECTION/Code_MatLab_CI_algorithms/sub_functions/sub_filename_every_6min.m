function filename_out=sub_filename_every_6min(filename)

year0=filename(12:15);
month0=filename(16:17);
day0=filename(18:19);
hour0=filename(21:22);
min0=filename(23:24);
time_now=[year0,'/',month0,'/',day0,' ',hour0,':',min0];

dt_6min=datenum('2017/5/5 00:06')-datenum('2017/5/5 00:00');
filename_out=cell(8,1);
temp=datestr(datenum(time_now)-1*dt_6min,31);filename_out(1,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_40dBZ.png']);
temp=datestr(datenum(time_now)-2*dt_6min,31);filename_out(2,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_40dBZ.png']);
temp=datestr(datenum(time_now)-3*dt_6min,31);filename_out(3,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_40dBZ.png']);
temp=datestr(datenum(time_now)-4*dt_6min,31);filename_out(4,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_40dBZ.png']);
temp=datestr(datenum(time_now)-5*dt_6min,31);filename_out(5,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_40dBZ.png']);
temp=datestr(datenum(time_now)-5*dt_6min,31);filename_out(6,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_25dBZ.png']);
temp=datestr(datenum(time_now)-5*dt_6min,31);filename_out(7,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_35dBZ.png']);
temp=datestr(datenum(time_now)-10*dt_6min,31);filename_out(8,1)=cellstr([filename(1:11),temp([1:4,6:7,9:10]),'_',temp([12:13,15:16]),'_25dBZ.png']);

end
