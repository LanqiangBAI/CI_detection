function ECHO=sub_get_echo_from_RGB(datapath,filename0)

filename=[datapath,filename0];
A=imread(filename);
s=size(A);
echo = nan(s(1),s(2));
k1=0;k2=0;k3=0;k4=0;k5=0;k6=0;
buffer_grids=6;

% determine the colors of the geographic boundaries and Chinese
% characters

county_1=uint8(189);    county_2=uint8(189);     county_3=uint8(197);
province_1=uint8(150);  province_2=uint8(150);   province_3=uint8(150);
character_1=uint8(104); character_2=uint8(104);  character_3=uint8(104);
river_1=uint8(181);     river_2=uint8(214);      river_3=uint8(234);

for i=1:s(1)
    for j=1:s(2)
        if A(i,j,1)==uint8(216)&&A(i,j,2)==uint8(216)&&A(i,j,3)==uint8(216)
            echo(i,j) = nan;
        elseif A(i,j,1)==uint8(1)&&A(i,j,2)==uint8(160)&&A(i,j,3)==uint8(246)
            echo(i,j) = 10;
        elseif A(i,j,1)==uint8(0)&&A(i,j,2)==uint8(236)&&A(i,j,3)==uint8(236)
            echo(i,j) = 15;
        elseif A(i,j,1)==uint8(0)&&A(i,j,2)==uint8(216)&&A(i,j,3)==uint8(0)
            echo(i,j) = 20;    
        elseif A(i,j,1)==uint8(1)&&A(i,j,2)==uint8(144)&&A(i,j,3)==uint8(0)
            echo(i,j) = 25;
        elseif A(i,j,1)==uint8(255)&&A(i,j,2)==uint8(255)&&A(i,j,3)==uint8(0)
            echo(i,j) = 30;    
        elseif A(i,j,1)==uint8(231)&&A(i,j,2)==uint8(192)&&A(i,j,3)==uint8(0)
            echo(i,j) = 35;
        elseif A(i,j,1)==uint8(255)&&A(i,j,2)==uint8(144)&&A(i,j,3)==uint8(0)
            echo(i,j) = 40;
        elseif A(i,j,1)==uint8(255)&&A(i,j,2)==uint8(0)&&A(i,j,3)==uint8(0)
            echo(i,j) = 45;
        elseif A(i,j,1)==uint8(214)&&A(i,j,2)==uint8(0)&&A(i,j,3)==uint8(0)
            echo(i,j) = 50;
        elseif A(i,j,1)==uint8(192)&&A(i,j,2)==uint8(0)&&A(i,j,3)==uint8(0)
            echo(i,j) = 55;
        elseif A(i,j,1)==uint8(255)&&A(i,j,2)==uint8(0)&&A(i,j,3)==uint8(240)
            echo(i,j) = 60;
        elseif A(i,j,1)==uint8(150)&&A(i,j,2)==uint8(0)&&A(i,j,3)==uint8(180)
            echo(i,j) = 65;    
        elseif A(i,j,1)==uint8(173)&&A(i,j,2)==uint8(144)&&A(i,j,3)==uint8(240)
            echo(i,j) = 70;
        elseif A(i,j,1)==county_1 &&A(i,j,2)==county_2&&A(i,j,3)==county_3
            if i>buffer_grids&&i<s(1)-buffer_grids&&j>buffer_grids&&j<s(2)-buffer_grids
                k1=k1+1;
                county_i(k1)=i; county_j(k1)=j; 
                echo(i,j) = nan;
            end   
        elseif A(i,j,1)==province_1&&A(i,j,2)==province_2&&A(i,j,3)==province_3
            if i>buffer_grids&&i<s(1)-buffer_grids&&j>buffer_grids&&j<s(2)-buffer_grids
                k2=k2+1;
                province_i(k2)=i; province_j(k2)=j; 
                echo(i,j) = nan;
            end
        elseif A(i,j,1)==character_1&&A(i,j,2)==character_2&&A(i,j,3)==character_3
            if i>buffer_grids&&i<s(1)-buffer_grids&&j>buffer_grids&&j<s(2)-buffer_grids
                k3=k3+1;
                cityname_i(k3)=i; cityname_j(k3)=j; 
                echo(i,j) = nan;
            end         
        
        elseif A(i,j,1)==river_1&&A(i,j,2)==river_2&&A(i,j,3)==river_3
            if i>buffer_grids&&i<s(1)-buffer_grids&&j>buffer_grids&&j<s(2)-buffer_grids
                k4=k4+1;
                river_i(k4)=i; river_j(k4)=j; 
                echo(i,j) = nan;
            end   
        end
    end
    
end

%% missing data interporation: using cressman method.
ECHO=echo;
R0=buffer_grids;
for k=1:k4
    [data_lon,data_lat]=meshgrid(river_i(k)-R0:river_i(k)+R0,river_j(k)-R0:river_j(k)+R0);
    ECHO(river_i(k),river_j(k))=sub_cressman(river_i(k),river_j(k),data_lon,data_lat,echo(river_i(k)-R0:river_i(k)+R0,river_j(k)-R0:river_j(k)+R0),R0,0);
end
ECHO=round(ECHO/5)*5;
echo=ECHO;
gridpoint=1;
for k=1:k1
    ECHO(county_i(k),county_j(k))=round(nanmean(nanmean(echo(county_i(k)-gridpoint:county_i(k)+gridpoint,county_j(k)-gridpoint:county_j(k)+gridpoint)))/5)*5;
end
for k=1:k2
    ECHO(province_i(k),province_j(k))=round(nanmean(nanmean(echo(province_i(k)-gridpoint:province_i(k)+gridpoint,province_j(k)-gridpoint:province_j(k)+gridpoint)))/5)*5;
end
for k=1:k3
    ECHO(cityname_i(k),cityname_j(k))=round(nanmean(nanmean(echo(cityname_i(k)-gridpoint:cityname_i(k)+gridpoint,cityname_j(k)-gridpoint:cityname_j(k)+gridpoint)))/5)*5;
end
for k=1:k5
    ECHO(sites_i(k),sites_j(k))=round(nanmean(nanmean(echo(sites_i(k)-gridpoint:sites_i(k)+gridpoint,sites_j(k)-gridpoint:sites_j(k)+gridpoint)))/5)*5;
end
end
