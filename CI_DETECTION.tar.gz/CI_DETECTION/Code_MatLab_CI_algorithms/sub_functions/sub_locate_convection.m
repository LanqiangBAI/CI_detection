function [bw_img,img_reg]=sub_locate_convection(datapath,image_name)    
    img =  imread([datapath,image_name]);
    P=2;conn=4;% P: removes from a binary image all connected components (objects) that have fewer than P pixels
               % conn: two-dimensional four-connected neighborhood
%% get binary image  
    gray_img=img;
    T = graythresh(gray_img);  
    bw_img = imbinarize(gray_img, T);  
    BW2 = bwareaopen(bw_img,P,conn);
    img_reg = regionprops(BW2,'boundingbox','Centroid');
end